# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _, tools
from odoo.osv import expression
from odoo.exceptions import UserError, ValidationError

class OppOpp(models.Model):
   _name = 'opp.opp'
   _description = 'Opportunity'

   @api.model
   def create(self, vals):
      """Membuat functiion untuk menambah Project Id"""
      if vals.get('name', 'New') == 'New':
         vals['name'] = self.env['ir.sequence'].next_by_code(
            'opp.opp') or 'New'
      result = super(OppOpp, self). create(vals)
      return result

   name = fields.Char(string="Project ID", required=True, readonly=True, copy=False, default='New')
   proj_name = fields.Char(string="Project Name")
   proj_desc = fields.Char(string="Project Description")
   amount = fields.Float(string="Amount")
   cust_id = fields.Many2one("cust.cust", string="Customer")
   cust_type_id = fields.Many2one("cust.type", string="Customer Type")
   lok_doc_id = fields.Many2one("lok.doc", string="Lokasi Docking")
   tgl_mulai = fields.Datetime(string="Tanggal Mulai")
   durasi_pekerjaan = fields.Integer(string="Durasi Pekerjaan")
   satuan_durasi_id = fields.Many2one("stn.durasi", string="Satuan Durasi")
   tgl_selesai = fields.Datetime(string="Tanggal Selesai")
   status_opp_id = fields.Many2one("status.opp", string="Status Opportunity")
   create_date = fields.Datetime(string="Upload Date")
   lead_time = fields.Integer(string="Total Lead Time")
   file_upload_ids = fields.One2many("file.upload", "opportunity_id",string="File Upload")
   status_opp = fields.Selection(selection=[
      ("draft", "Draft"),
      ("send", "Send"),
      ("done", "Done"),
      ("hold", "Hold"),
      ("inactive", "Inactive"),
   ], string="Status", required=True, readonly=True, copy=False,
   tracking=True, default="draft")
   def button_send(self):
       self.write({'status_opp': "send"})
       self.write({'p_status': "active"})

   def button_done(self):
       self.write({
           'status_opp': "done"
       })

   p_proj_def = fields.Char(string="Project Definition")
   p_budget = fields.Float(string="Budget")
   p_tot_amount_pr = fields.Float(string="Total Amount PR")
   p_tot_amount_contract = fields.Float(string="Total Amount Contract")
   p_sisa_budget = fields.Float(string="Sisa Budget")
   p_name_pic = fields.Char(string="Nama PIC")
   p_status = fields.Selection(selection=[
      ("new", "New"),
      ("active", "Active"),
      ("done", "Done"),
      ("hold", "Hold"),
      ("inactive", "Inactive"),
   ], string="Status", required=True, readonly=True, copy=False,
   tracking=True, default="new")

   def button_done_pengadaan(self):
       self.write({'p_status': "done"})

   metode_p_id = fields.Many2one("metode.metode", string="Metode")
   p_file_upload_ids = fields.One2many("p.fileupload", "opportunity_id",string="File Upload")
