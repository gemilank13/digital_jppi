# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class PFileupload(models.Model):
    _name = 'p.fileupload'
    _description = 'Pengadaan File Upload'

    name = fields.Many2one("jenis.dok", string="Jenis Dokumen", required=True)
    file_upload = fields.Binary(string="Upload File")
    file_desc = fields.Char(string="Description")
    amount = fields.Float(string="Amount")
    upload_date = fields.Datetime(string="Upload Date")
    upload_by = fields.Char(string="Uploaded By")
    opportunity_id = fields.Many2one("opp.opp", string="Opportunity ID", readonly=True)