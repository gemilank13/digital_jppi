# -*- coding: utf-8 -*-
from odoo import models, fields, api, exceptions, _

class Workorders(models.Model):
    _name = 'workorders.workorders'
    _description = 'Work Orders'

    @api.multi
    def btn_submit(self, vals):
        for rec in self:
            rec.write({'status': 'waiting'})

    @api.multi
    def btn_approved(self, vals):
        for rec in self:
            rec.write({'status': 'approved'})

    @api.multi
    def btn_close(self, vals):
        for rec in self:
            rec.write({'status': 'close'})



    @api.model
    def create(self, vals):
        obj = super(Workorders, self).create(vals)
        if obj.name == '/':
            number = self.env['ir.sequence'].get('name.sequence.code') or '/'
            obj.write({'name': number})
        return obj

    name = fields.Char(string="WO#", default='/', readonly=True)
    unit_id = fields.Many2one('unit.unit', string="Unit")
    wo_oracle = fields.Char(string="WO# Oracle")
    cust_id = fields.Many2one('res.partner', string="Customer")
    nama_pekerja = fields.Many2one('hr.employee', string="Nama Pekerjaan")
    cabang = fields.Many2one("stock.warehouse",string="Cabang")
    status = fields.Selection([
    	('draft', 'Draft'),
        ('waiting', 'Waiting'),
        ('approved', 'Approved'),
        ('close', 'Close'),
        ], string='Status', store=True, default="draft")
    tanggal = fields.Datetime(string="Tanggal")
    workorders_line_ids = fields.One2many("workorders.line", "workorders_id", string="Work Orders Line")


class WorkordersLine(models.Model):
    _name ='workorders.line'
    _description = 'Work Order Line'

    name = fields.Many2one("product.product", string="Product")
    uom = fields.Char(string="UoM")
    qty = fields.Float(string="Qty")
    tagih_ok = fields.Boolean(string="Ditagihkan") 
    workorders_id = fields.Many2one("workorders.workorders", string="Workorders Id")

class UnitUnit(models.Model):
    _name ='unit.unit'
    _description = 'Units'

    name = fields.Char(string="Name")